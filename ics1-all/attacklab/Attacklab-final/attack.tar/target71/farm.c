/* This function marks the start of the farm */
int start_farm()
{
    return 1;
}

unsigned getval_426()
{
    return 3347662943U;
}

unsigned addval_454(unsigned x)
{
    return x + 2425393496U;
}

unsigned getval_109()
{
    return 3347663066U;
}

void setval_431(unsigned *p)
{
    *p = 3281031256U;
}

unsigned addval_262(unsigned x)
{
    return x + 2425444548U;
}

void setval_423(unsigned *p)
{
    *p = 3281031256U;
}

void setval_204(unsigned *p)
{
    *p = 3339274288U;
}

unsigned getval_304()
{
    return 3351742792U;
}

/* This function marks the middle of the farm */
int mid_farm()
{
    return 1;
}

/* Add two arguments */
long add_xy(long x, long y)
{
    return x+y;
}

void setval_329(unsigned *p)
{
    *p = 3523789065U;
}

unsigned addval_318(unsigned x)
{
    return x + 2425670281U;
}

void setval_422(unsigned *p)
{
    *p = 3268053299U;
}

unsigned getval_247()
{
    return 2430635336U;
}

unsigned addval_315(unsigned x)
{
    return x + 3286288712U;
}

unsigned addval_340(unsigned x)
{
    return x + 3247491721U;
}

unsigned addval_406(unsigned x)
{
    return x + 3281049229U;
}

void setval_220(unsigned *p)
{
    *p = 3375942285U;
}

unsigned addval_171(unsigned x)
{
    return x + 2429192652U;
}

void setval_359(unsigned *p)
{
    *p = 3286272328U;
}

unsigned getval_483()
{
    return 2425536905U;
}

unsigned addval_148(unsigned x)
{
    return x + 3224947369U;
}

unsigned getval_202()
{
    return 3532969609U;
}

unsigned getval_207()
{
    return 3353381192U;
}

unsigned addval_413(unsigned x)
{
    return x + 3536115337U;
}

void setval_263(unsigned *p)
{
    *p = 2430634824U;
}

unsigned addval_196(unsigned x)
{
    return x + 2425667977U;
}

unsigned addval_155(unsigned x)
{
    return x + 3285617085U;
}

void setval_452(unsigned *p)
{
    *p = 3286276424U;
}

unsigned addval_153(unsigned x)
{
    return x + 2430634312U;
}

unsigned getval_365()
{
    return 3380923017U;
}

void setval_321(unsigned *p)
{
    *p = 3682910617U;
}

void setval_419(unsigned *p)
{
    *p = 3281049225U;
}

unsigned getval_300()
{
    return 3534012809U;
}

void setval_284(unsigned *p)
{
    *p = 3769190454U;
}

unsigned getval_217()
{
    return 2425476745U;
}

void setval_435(unsigned *p)
{
    *p = 3284834642U;
}

unsigned addval_339(unsigned x)
{
    return x + 3680551305U;
}

void setval_101(unsigned *p)
{
    *p = 1170456969U;
}

void setval_216(unsigned *p)
{
    *p = 3526934921U;
}

unsigned addval_130(unsigned x)
{
    return x + 3221804680U;
}

unsigned addval_110(unsigned x)
{
    return x + 3682129545U;
}

/* This function marks the end of the farm */
int end_farm()
{
    return 1;
}
